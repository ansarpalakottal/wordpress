<?php
$construction_cat_list = Construction_Category_list();
$construction_posts_list = Construction_Posts_List();
$construction_font_size = construction_font_size();
$construction_fonts = construction_fonts();
 
 /** Customizers Panels **/
 $wp_customize->add_panel(
    'construction_general_panel',array(
        'title' => __('General Setting','construction'),
        'priority' => 2,
    )
 );
 $wp_customize->add_panel(
    'construction_header_panel',array(
        'title' => __('Header Setting','construction'),
        'description' => __('All The Header Setting Available Here','construction'),
        'priority' => 2,
    )
 );
 $wp_customize->add_panel(
    'construction_home_panel',
    array(
        'title' => __('Home Setting','construction'),
        'description' => __('All The Setting For Home Sections','construction'),
        'priority' => 3
    )
 );
 $wp_customize->add_panel(
    'construction_typography_panel',
    array(
        'title' => __('Typography Setting','construction'),
        'priority' => 5
    )
 );
 $wp_customize->add_panel(
    'construction_footer_panel',
    array(
        'title' => __('Footer Setting','construction'),
        'priority' => 4
    )
 );
 
 /** Customizer Sections **/
 $wp_customize->add_section(
    'construction_menu_section',
    array(
        'title' => __('Menu Section','construction'),
        'description' => __('All The Settings For Menu','construction'),
        'priority' => 3,
        'panel' => 'construction_header_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_slider_section',
    array(
        'title' => __('Slider Section','construction'),
        'description' => __('All The Settings For Slider','construction'),
        'priority' => 5,
        'panel' => 'construction_header_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_page_section',
    array(
        'title' => __('Page Breadcrumb','construction'),
        'priority' => 6,
        'panel' => 'construction_general_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_about_section',
    array(
        'title' => __('About Us Section','construction'),
        'priority' => 3,
        'panel' => 'construction_home_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_feature_section',
    array(
        'title' => __('Feature Section','construction'),
        'priority' => 6,
        'panel' => 'construction_home_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_team_section',
    array(
        'title' => __('Team Section','construction'),
        'priority' => 8,
        'panel' => 'construction_home_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_portfolio_section',
    array(
        'title' => __('Portfolio Section','construction'),
        'priority' => 10,
        'panel' => 'construction_home_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_blog_section',
    array(
        'title' => __('Blog Section','construction'),
        'priority' => 12,
        'panel' => 'construction_home_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_cta_section',
    array(
        'title' => __('Call To Action Section','construction'),
        'priority' => 14,
        'panel' => 'construction_home_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_shop_section',
    array(
        'title' => __('Shop Section','construction'),
        'priority' => 15,
        'panel' => 'construction_home_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_testimonial_section',
    array(
        'title' => __('Testimonial Section','construction'),
        'priority' => 16,
        'panel' => 'construction_home_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_client_section',
    array(
        'title' => __('Client Section','construction'),
        'priority' => 18,
        'panel' => 'construction_home_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_top_footer_section',
    array(
        'title' => __('Top Footer Section','construction'),
        'priority' => 2,
        'panel' => 'construction_footer_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_bottom_footer_section',
    array(
        'title' => __('Bottom Footer Section','construction'),
        'priority' => 4,
        'panel' => 'construction_footer_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_body_typography_section',
    array(
        'title' => __('Body','construction'),
        'priority' => 4,
        'panel' => 'construction_typography_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_h1_typography_section',
    array(
        'title' => __('Heading 1','construction'),
        'priority' => 5,
        'panel' => 'construction_typography_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_h2_typography_section',
    array(
        'title' => __('Heading 2','construction'),
        'priority' => 6,
        'panel' => 'construction_typography_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_h3_typography_section',
    array(
        'title' => __('Heading 3','construction'),
        'priority' => 7,
        'panel' => 'construction_typography_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_h4_typography_section',
    array(
        'title' => __('Heading 4','construction'),
        'priority' => 8,
        'panel' => 'construction_typography_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_h5_typography_section',
    array(
        'title' => __('Heading 5','construction'),
        'priority' => 9,
        'panel' => 'construction_typography_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_h6_typography_section',
    array(
        'title' => __('Heading 6','construction'),
        'priority' => 10,
        'panel' => 'construction_typography_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 $wp_customize->add_section(
    'construction_contact_page',
    array(
        'title' => __('Contact Page Setting','construction'),
        'priority' => 10,
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
  $wp_customize->add_section(
    'construction_skin_color_section',
    array(
        'title' => __('Skin Color Section','construction'),
        'priority' => 10,
        'panel' => 'construction_general_panel',
        'capability' => 'edit_theme_options',
        'theme_support' => ''
    )
 );
 /** Customizer Settings And Control **/
 $wp_customize->add_setting(
    'construction_search_enable',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_checkbox'
    )
 );
 $wp_customize->add_control(
    'construction_search_enable',
    array(
        'label' => __('Check Enable Search On Menu','construction'),
        'priority' => 2,
        'type' => 'checkbox',
        'section' => 'construction_menu_section'
    )
 );
 $wp_customize->add_setting(
    'construction_cart_enable',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_checkbox'
    )
 );
 $wp_customize->add_control(
    'construction_cart_enable',
    array(
        'label' => __('Check Enable Cart On Menu','construction'),
        'priority' => 4,
        'type' => 'checkbox',
        'section' => 'construction_menu_section'
    )
 );
 $wp_customize->add_setting(
    'construction_slider_enable',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_checkbox'
    )
 );
 $wp_customize->add_control(
    'construction_slider_enable',
    array(
        'label' => __('Check Enable Slider','construction'),
        'priority' => 1,
        'type' => 'checkbox',
        'section' => 'construction_slider_section'
    )
 );
 $wp_customize->add_setting(
    'construction_slider_cat',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_post_cat_list',
    )
 );
 $wp_customize->add_control(
    'construction_slider_cat',
    array(
        'label' => __('Slider Category','construction'),
        'priority' => 3,
        'type' => 'select',
        'choices' => $construction_cat_list,
        'section' => 'construction_slider_section'
    )
 );
 $wp_customize->add_setting(
    'construction_page_bg_image',
    array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    )
 );
 $wp_customize->add_control(
       new WP_Customize_Image_Control(
           $wp_customize,
           'construction_page_bg_image',
           array(
               'label'      => __( 'Page Breadcrumb Backgeound Image', 'construction' ),
               'section'    => 'construction_page_section',
               'settings'   => 'construction_page_bg_image',
               'priority' => 10,
           )
       )
   );
 $wp_customize->add_setting(
    'construction_about_enable',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_checkbox'
    )
 );
 $wp_customize->add_control(
    'construction_about_enable',
    array(
        'label' => __('Enable About US','construction'),
        'priority' => 1,
        'type' => 'checkbox',
        'section' => 'construction_about_section'
    )
 );
 $wp_customize->add_setting(
    'construction_about_title',
    array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'=>'postMessage',
    )
 );
 $wp_customize->add_control(
    'construction_about_title',
    array(
        'label' => __('About Us Section Title','construction'),
        'type' => 'text',
        'priority' => 4,
        'section' => 'construction_about_section'
    )
 );
 $wp_customize->add_setting(
    'construction_about_sub_title',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_about_sub_title',
    array(
        'label' => __('About Us Section Sub Title','construction'),
        'type' => 'text',
        'priority' => 6,
        'section' => 'construction_about_section'
    )
 );
  $wp_customize->add_setting(
    'construction_about_post',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_post_select',
    )
  );
  $wp_customize->add_control(
    'construction_about_post',
    array(
        'label' => __('About Us Post','construction'),
        'type' => 'select',
        'choices' => $construction_posts_list,
        'section' => 'construction_about_section',
        'priority' => 10
    )
  );
 $wp_customize->add_setting(
    'construction_disable_feature_image_frame',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_checkbox'
    )
 );
 $wp_customize->add_control(
    'construction_disable_feature_image_frame',
    array(
        'label' => __('Disable Feature Image Frame','construction'),
        'type' => 'checkbox',
        'priority' => 12,
        'section' => 'construction_about_section'
    )
 );
 $wp_customize->add_setting(
    'construction_feature_enable',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_checkbox'
    )
 );
 $wp_customize->add_control(
    'construction_feature_enable',
    array(
        'label' => __('Enable Feature Section','construction'),
        'type' => 'checkbox',
        'priority' => '2',
        'section' => 'construction_feature_section'
    )
 );
$wp_customize->add_setting(
    'construction_feature_title',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_feature_title',
    array(
        'label' => __('Feature Section Title','construction'),
        'type' => 'text',
        'priority' => 4,
        'section' => 'construction_feature_section'
    )
 );
 $wp_customize->add_setting(
    'construction_feature_sub_title',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_feature_sub_title',
    array(
        'label' => __('Feature Section Sub Title','construction'),
        'type' => 'text',
        'priority' => 6,
        'section' => 'construction_feature_section'
    )
 );
 $wp_customize->add_setting(
    'construction_feature_cat',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_post_cat_list'
    )
 );
 $wp_customize->add_control(
    'construction_feature_cat',
    array(
        'label' => __('Feature Post Category','construction'),
        'type' => 'select',
        'choices' => $construction_cat_list,
        'section' => 'construction_feature_section',
        'priority' => 8,
    )
 );
 $wp_customize->add_setting(
    'construction_feature_image',
    array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    )
 );
 $wp_customize->add_control(
       new WP_Customize_Image_Control(
           $wp_customize,
           'construction_feature_image',
           array(
               'label'      => __( 'Feature Section Image', 'construction' ),
               'section'    => 'construction_feature_section',
               'settings'   => 'construction_feature_image',
               'priority' => 10,
           )
       )
   );
 $wp_customize->add_setting(
    'construction_team_enable',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_checkbox'
    )
 );
 $wp_customize->add_control(
    'construction_team_enable',
    array(
        'label' => __('Enable Team','construction'),
        'priority' => 1,
        'type' => 'checkbox',
        'section' => 'construction_team_section'
    )
 );
 $wp_customize->add_setting(
    'construction_team_title',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_team_title',
    array(
        'label' => __('Team Section Title','construction'),
        'type' => 'text',
        'priority' => 4,
        'section' => 'construction_team_section'
    )
 );
 $wp_customize->add_setting(
    'construction_team_sub_title',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_team_sub_title',
    array(
        'label' => __('Team Section Sub Title','construction'),
        'type' => 'text',
        'priority' => 6,
        'section' => 'construction_team_section'
    )
 );
 $wp_customize->add_setting(
    'construction_portfolio_enable',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_checkbox'
    )
 );
 $wp_customize->add_control(
    'construction_portfolio_enable',
    array(
        'label' => __('Enable Portfolio','construction'),
        'priority' => 1,
        'type' => 'checkbox',
        'section' => 'construction_portfolio_section'
    )
 );
 $wp_customize->add_setting(
    'construction_portfolio_title',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_portfolio_title',
    array(
        'label' => __('Portfolio Section Title','construction'),
        'type' => 'text',
        'priority' => 4,
        'section' => 'construction_portfolio_section'
    )
 );
 $wp_customize->add_setting(
    'construction_portfolio_sub_title',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_portfolio_sub_title',
    array(
        'label' => __('Portfolio Section Sub Title','construction'),
        'type' => 'text',
        'priority' => 6,
        'section' => 'construction_portfolio_section'
    )
 );
 $wp_customize->add_setting(
    'construction_portfolio_cat',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_post_cat_list'
    )
 );
 $wp_customize->add_control(
    'construction_portfolio_cat',
    array(
        'label' => __('Portfolio Post Category','construction'),
        'type' => 'select',
        'choices' => $construction_cat_list,
        'section' => 'construction_portfolio_section',
        'priority' => 8,
    )
 );
  $wp_customize->add_setting(
    'construction_blog_enable',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_checkbox'
    )
 );
 $wp_customize->add_control(
    'construction_blog_enable',
    array(
        'label' => __('Enable Bolog Section','construction'),
        'priority' => 1,
        'type' => 'checkbox',
        'section' => 'construction_blog_section'
    )
 );
 $wp_customize->add_setting(
    'construction_blog_title',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_blog_title',
    array(
        'label' => __('Blog Section Title','construction'),
        'type' => 'text',
        'priority' => 4,
        'section' => 'construction_blog_section'
    )
 );
 $wp_customize->add_setting(
    'construction_blog_sub_title',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_blog_sub_title',
    array(
        'label' => __('Blog Section Sub Title','construction'),
        'type' => 'text',
        'priority' => 6,
        'section' => 'construction_blog_section'
    )
 );
 $wp_customize->add_setting(
    'construction_blog_cat',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_post_cat_list'
    )
 );
 $wp_customize->add_control(
    'construction_blog_cat',
    array(
        'label' => __('Blog Post Category','construction'),
        'type' => 'select',
        'choices' => $construction_cat_list,
        'section' => 'construction_blog_section',
        'priority' => 8,
    )
 );
 $wp_customize->add_setting(
    'construction_cta_enable',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_checkbox'
    )
 );
 $wp_customize->add_control(
    'construction_cta_enable',
    array(
        'label' => __('Enable Call To Action Section','construction'),
        'priority' => 1,
        'type' => 'checkbox',
        'section' => 'construction_cta_section'
    )
 );
 $wp_customize->add_setting(
    'construction_cta_title',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_cta_title',
    array(
        'label' => __('Call To Action Section Title','construction'),
        'type' => 'text',
        'priority' => 4,
        'section' => 'construction_cta_section'
    )
 );
 $wp_customize->add_setting(
    'construction_cta_section_description',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'construction_sanitize_textarea'
    )
 );
 $wp_customize->add_control(
    'construction_cta_section_description',
    array(
        'label' => __('Call To Action Section Description','construction'),
        'type' => 'textarea',
        'priority' => 6,
        'section' => 'construction_cta_section'
    )
 );
 $wp_customize->add_setting(
    'construction_cta_button_text',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_cta_button_text',
    array(
        'label' => __('Call To Action Button Text','construction'),
        'type' => 'text',
        'priority' => 8,
        'section' => 'construction_cta_section'
    )
 );
 $wp_customize->add_setting(
    'construction_cta_button_link',
    array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    )
 );
 $wp_customize->add_control(
    'construction_cta_button_link',
    array(
        'label' => __('Call To Action Button Link','construction'),
        'type' => 'text',
        'priority' =>10,
        'section' => 'construction_cta_section'
    )
 );
 $wp_customize->add_setting(
    'construction_cta_bg_image',
    array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    )
 );
 $wp_customize->add_control(
       new WP_Customize_Image_Control(
           $wp_customize,
           'construction_cta_bg_image',
           array(
               'label'      => __( 'Section Background Image', 'construction' ),
               'section'    => 'construction_cta_section',
               'settings'   => 'construction_cta_bg_image',
               'priority' => 15,
           )
       )
   );
 $wp_customize->add_setting(
    'construction_shop_enable',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_checkbox'
    )
 );
 $wp_customize->add_control(
    'construction_shop_enable',
    array(
        'label' => __('Enable Shop Section','construction'),
        'priority' => 1,
        'type' => 'checkbox',
        'section' => 'construction_shop_section'
    )
 );
 $wp_customize->add_setting(
    'construction_shop_title',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_shop_title',
    array(
        'label' => __('Shop Section Title','construction'),
        'type' => 'text',
        'priority' => 4,
        'section' => 'construction_shop_section'
    )
 );
 $wp_customize->add_setting(
    'construction_shop_sub_title',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_shop_sub_title',
    array(
        'label' => __('Shop Section Sub Title','construction'),
        'type' => 'text',
        'priority' => 6,
        'section' => 'construction_shop_section'
    )
 );
 $wp_customize->add_setting(
    'construction_testimonial_enable',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_checkbox'
    )
 );
 $wp_customize->add_control(
    'construction_testimonial_enable',
    array(
        'label' => __('Enable Testimonial Section','construction'),
        'priority' => 1,
        'type' => 'checkbox',
        'section' => 'construction_testimonial_section'
    )
 );
 $wp_customize->add_setting(
    'construction_testimonial_title',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_testimonial_title',
    array(
        'label' => __('Testimonial Section Title','construction'),
        'type' => 'text',
        'priority' => 4,
        'section' => 'construction_testimonial_section'
    )
 );
 $wp_customize->add_setting(
    'construction_testimonial_sub_title',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_testimonial_sub_title',
    array(
        'label' => __('Testimonial Section Sub Title','construction'),
        'type' => 'text',
        'priority' => 6,
        'section' => 'construction_testimonial_section'
    )
 );
 $wp_customize->add_setting(
    'construction_testimonial_cat',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_post_cat_list'
    )
 );
 $wp_customize->add_control(
    'construction_testimonial_cat',
    array(
        'label' => __('Testimonial Post Category','construction'),
        'type' => 'select',
        'choices' => $construction_cat_list,
        'section' => 'construction_testimonial_section',
        'priority' => 8,
    )
 );
  $wp_customize->add_setting(
    'construction_client_enable',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_checkbox'
    )
 );
 $wp_customize->add_control(
    'construction_client_enable',
    array(
        'label' => __('Enable Client Section','construction'),
        'priority' => 1,
        'type' => 'checkbox',
        'section' => 'construction_client_section'
    )
 );
 $wp_customize->add_setting(
    'construction_client_cat',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_post_cat_list'
    )
 );
 $wp_customize->add_control(
    'construction_client_cat',
    array(
        'label' => __('Client Post Category','construction'),
        'type' => 'select',
        'choices' => $construction_cat_list,
        'section' => 'construction_client_section',
        'priority' => 4,
    )
 );
 $wp_customize->add_setting(
    'construction_top_footer_enable',
    array(
        'default' => '',
        'sanitize_callback' => 'construction_sanitize_checkbox'
    )
 );
 $wp_customize->add_control(
    'construction_top_footer_enable',
    array(
        'label' => __('Enable Top Footer Section','construction'),
        'priority' => 1,
        'type' => 'checkbox',
        'section' => 'construction_top_footer_section'
    )
 );
 $wp_customize->add_setting(
    'construction_top_footer_logo',
    array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    )
 );
 $wp_customize->add_control(
       new WP_Customize_Image_Control(
           $wp_customize,
           'construction_top_footer_logo',
           array(
               'label'      => __( 'Top Footer Logo', 'construction' ),
               'section'    => 'construction_top_footer_section',
               'settings'   => 'construction_top_footer_logo',
               'priority' => 4,
           )
       )
   );
 $wp_customize->add_setting(
    'construction_top_footer_description',
    array(
        'default' => '',
        'transport' => 'postMessage',
        'sanitize_callback' => 'construction_sanitize_textarea'
    )
 );
 $wp_customize->add_control(
    'construction_top_footer_description',
    array(
        'label' => __('Top Footer Description','construction'),
        'type' => 'textarea',
        'priority' => 6,
        'section' => 'construction_top_footer_section'
    )
 );
 
 $wp_customize->add_setting(
    'construction_facebook_link',
    array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    )
 );
 $wp_customize->add_control(
    'construction_facebook_link',
    array(
        'label' => __('Facebook Link','construction'),
        'type' => 'text',
        'priority' => 8,
        'section' => 'construction_top_footer_section'
    )
 );
 $wp_customize->add_setting(
    'construction_twitter_link',
    array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    )
 );
 $wp_customize->add_control(
    'construction_twitter_link',
    array(
        'label' => __('Twitter Link','construction'),
        'type' => 'text',
        'priority' => 10,
        'section' => 'construction_top_footer_section'
    )
 );
 $wp_customize->add_setting(
    'construction_youtube_link',
    array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    )
 );
 $wp_customize->add_control(
    'construction_youtube_link',
    array(
        'label' => __('Youtube Link','construction'),
        'type' => 'text',
        'priority' => 12,
        'section' => 'construction_top_footer_section'
    )
 );
 $wp_customize->add_setting(
    'construction_pinterest_link',
    array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    )
 );
 $wp_customize->add_control(
    'construction_pinterest_link',
    array(
        'label' => __('Pinterest Link','construction'),
        'type' => 'text',
        'priority' => 14,
        'section' => 'construction_top_footer_section'
    )
 );
 $wp_customize->add_setting(
    'construction_instagram_link',
    array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    )
 );
 $wp_customize->add_control(
    'construction_instagram_link',
    array(
        'label' => __('Instagram Link','construction'),
        'type' => 'text',
        'priority' => 16,
        'section' => 'construction_top_footer_section'
    )
 );
 $wp_customize->add_setting(
    'construction_linkedin_link',
    array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    )
 );
 $wp_customize->add_control(
    'construction_linkedin_link',
    array(
        'label' => __('Linkedin Link','construction'),
        'type' => 'text',
        'priority' => 18,
        'section' => 'construction_top_footer_section'
    )
 );
 $wp_customize->add_setting(
    'construction_googleplus_link',
    array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    )
 );
 $wp_customize->add_control(
    'construction_googleplus_link',
    array(
        'label' => __('GooglePlus Link','construction'),
        'type' => 'text',
        'priority' => 20,
        'section' => 'construction_top_footer_section'
    )
 );
 $wp_customize->add_setting(
    'construction_flickr_link',
    array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    )
 );
 $wp_customize->add_control(
    'construction_flickr_link',
    array(
        'label' => __('Flickr Link','construction'),
        'type' => 'text',
        'priority' => 22,
        'section' => 'construction_top_footer_section'
    )
 );
 $wp_customize->add_setting(
    'construction_footer_text',
    array(
        'default' => '',
        'transport' => 'postMessage',
        'sanitize_callback' => 'sanitize_text_field'
    )
 );
 $wp_customize->add_control(
    'construction_footer_text',
    array(
        'label' => __('Footer Text','construction'),
        'type' => 'text',
        'priority' => 4,
        'section' => 'construction_bottom_footer_section'
    )
 );
$wp_customize->add_setting(
    'construction_body_font_size',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'construction_sanitize_font_size'
    )
);
 $wp_customize->add_control(
    'construction_body_font_size',
    array(
        'label' => __('Body Font Size','construction'),
        'priority' => 2,
        'type' => 'select',
        'choices' => $construction_font_size,
        'section' => 'construction_body_typography_section'
    )
 );
$wp_customize->add_setting(
    'construction_h1_font_size',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'construction_sanitize_font_size'
    )
);
$wp_customize->add_control(
    'construction_h1_font_size',
    array(
        'label' => __('Heading 1 Font Size','construction'),
        'priority' => 2,
        'type' => 'select',
        'choices' => $construction_font_size,
        'section' => 'construction_h1_typography_section'
    )
 );
$wp_customize->add_setting(
    'construction_h2_font_size',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'construction_sanitize_font_size'
    )
);
$wp_customize->add_control(
    'construction_h2_font_size',
    array(
        'label' => __('Heading 2 Font Size','construction'),
        'priority' => 2,
        'type' => 'select',
        'choices' => $construction_font_size,
        'section' => 'construction_h2_typography_section'
    )
 );
$wp_customize->add_setting(
    'construction_h3_font_size',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'construction_sanitize_font_size'
    )
);
$wp_customize->add_control(
    'construction_h3_font_size',
    array(
        'label' => __('Heading 3 Font Size','construction'),
        'priority' => 2,
        'type' => 'select',
        'choices' => $construction_font_size,
        'section' => 'construction_h3_typography_section'
    )
 );
$wp_customize->add_setting(
    'construction_h4_font_size',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'construction_sanitize_font_size'
    )
);
$wp_customize->add_control(
    'construction_h4_font_size',
    array(
        'label' => __('Heading 4 Font Size','construction'),
        'priority' => 2,
        'type' => 'select',
        'choices' => $construction_font_size,
        'section' => 'construction_h4_typography_section'
    )
 );
$wp_customize->add_setting(
    'construction_h5_font_size',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'construction_sanitize_font_size'
    )
);
$wp_customize->add_control(
    'construction_h5_font_size',
    array(
        'label' => __('Heading 5 Font Size','construction'),
        'priority' => 2,
        'type' => 'select',
        'choices' => $construction_font_size,
        'section' => 'construction_h5_typography_section'
    )
 );
$wp_customize->add_setting(
    'construction_h6_font_size',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'construction_sanitize_font_size'
    )
);
$wp_customize->add_control(
    'construction_h6_font_size',
    array(
        'label' => __('Heading 6 Font Size','construction'),
        'priority' => 2,
        'type' => 'select',
        'choices' => $construction_font_size,
        'section' => 'construction_h6_typography_section'
    )
 );
$wp_customize->add_setting(
    'construction_body_font',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'sanitize_text_field'
    )
);
$wp_customize->add_control(
    'construction_body_font',
    array(
        'label' => __('Body Font','construction'),
        'priority' => 4,
        'type' => 'select',
        'choices' => $construction_fonts,
        'section' => 'construction_body_typography_section'
    )
 );
$wp_customize->add_setting(
    'construction_h1_font',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'sanitize_text_field'
    )
);
$wp_customize->add_control(
    'construction_h1_font',
    array(
        'label' => __('Heading 1 Font','construction'),
        'priority' => 4,
        'type' => 'select',
        'choices' => $construction_fonts,
        'section' => 'construction_h1_typography_section'
    )
 );
$wp_customize->add_setting(
    'construction_h2_font',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'sanitize_text_field'
    )
);
$wp_customize->add_control(
    'construction_h2_font',
    array(
        'label' => __('Heading 2 Font','construction'),
        'priority' => 4,
        'type' => 'select',
        'choices' => $construction_fonts,
        'section' => 'construction_h2_typography_section'
    )
 );
$wp_customize->add_setting(
    'construction_h3_font',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'sanitize_text_field'
    )
);
$wp_customize->add_control(
    'construction_h3_font',
    array(
        'label' => __('Heading 3 Font','construction'),
        'priority' => 4,
        'type' => 'select',
        'choices' => $construction_fonts,
        'section' => 'construction_h3_typography_section'
    )
 );
$wp_customize->add_setting(
    'construction_h4_font',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'sanitize_text_field'
    )
);
$wp_customize->add_control(
    'construction_h4_font',
    array(
        'label' => __('Heading 4 Font','construction'),
        'priority' => 4,
        'type' => 'select',
        'choices' => $construction_fonts,
        'section' => 'construction_h4_typography_section'
    )
 );
$wp_customize->add_setting(
    'construction_h5_font',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'sanitize_text_field'
    )
);
$wp_customize->add_control(
    'construction_h5_font',
    array(
        'label' => __('Heading 5 Font','construction'),
        'priority' => 4,
        'type' => 'select',
        'choices' => $construction_fonts,
        'section' => 'construction_h5_typography_section'
    )
 );
$wp_customize->add_setting(
    'construction_h6_font',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'sanitize_text_field'
    )
);
$wp_customize->add_control(
    'construction_h6_font',
    array(
        'label' => __('Heading 6 Font','construction'),
        'priority' => 4,
        'type' => 'select',
        'choices' => $construction_fonts,
        'section' => 'construction_h6_typography_section'
    )
 );
 $wp_customize->add_setting(
    'construction_mape_iframe_page',
    array(
        'default' => '',
        'sanitize_callback'=>'construction_sanitize_post_select'
    )
);
 $wp_customize->add_control(
    'construction_mape_iframe_page',
    array(
        'label' => __('Map Iframe Post','construction'),
        'priority' => 2,
        'type' => 'select',
        'choices' => $construction_posts_list,
        'section' => 'construction_contact_page'
    )
 );
 $wp_customize->add_setting(
    'construction_contact_form_title',
    array(
        'default' => '',
        'sanitize_callback'=>'sanitize_text_field'
    )
);
 $wp_customize->add_control(
    'construction_contact_form_title',
    array(
        'label' => __('Contact Form Title','construction'),
        'priority' => 4,
        'type' => 'text',
        'section' => 'construction_contact_page'
    )
 );
 $wp_customize->add_setting(
    'construction_contact_form_description',
    array(
        'default' => '',
        'sanitize_callback'=>'construction_sanitize_textarea'
    )
);
 $wp_customize->add_control(
    'construction_contact_form_description',
    array(
        'label' => __('Contact Form Description','construction'),
        'priority' => 6,
        'type' => 'textarea',
        'section' => 'construction_contact_page'
    )
 );
 $wp_customize->add_setting(
    'construction_contact_page',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'construction_sanitize_post_select'
    )
);
$wp_customize->add_control(
    'construction_contact_page',
    array(
        'label' => __('Contact Form Post Page','construction'),
        'priority' => 8,
        'type' => 'select',
        'choices' => $construction_posts_list,
        'section' => 'construction_contact_page'
    )
 );
 $wp_customize->add_setting(
    'construction_skin_color',
    array(
        'default' => '',
        'transport'=>'postMessage',
        'sanitize_callback'=>'sanitize_text_field'
    )
);
$wp_customize->add_control(
    'construction_skin_color',
    array(
        'label' => __('Skin Color','construction'),
        'priority' => 8,
        'type' => 'radio',
        'choices' => array(
            '' => __('Default','construction'),
            '#E9967A' => __('DarkSalmon','construction'),
            '#800000' => __('Maroon','construction'),
            '#00a0d2' => __('Tomato','construction'),
        ),
        'section' => 'construction_skin_color_section'
    )
 );